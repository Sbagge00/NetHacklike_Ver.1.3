#ifndef ITEM_H
#define ITEM_H

#include "weapon.h"
#include "armor.h"
// #include "potion.h"


typedef enum { WEAPON_TYPE, ARMOR_TYPE, SCROLL_TYPE, SPELLBOOK_TYPE, POTION_TYPE} ItemType;

typedef struct item
{
    ItemType type;
    Position * position;

    union {
        Weapon * weapon;
        Potion * potion;
    } Item;

    char string[256];

} Item;

#ifend
