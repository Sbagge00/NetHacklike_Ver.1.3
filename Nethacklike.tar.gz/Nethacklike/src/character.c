#include "rogue.h"

int spells(Position * newPosition, Player * user, char ** level)
{
  user->spellSlot = (((1 * user->level) / 2) + 1);
}


int health(Position * newPosition, Player * user, char ** level)
{
  raw();
  start_color();

  if (user->hp == user->maxhp)
  {
	  init_pair(1,COLOR_BLACK, COLOR_GREEN);
	  attron(COLOR_PAIR(1));
	  if (user->class == 8) {
	      mvprintw(30, 2, "       Choose Class    ");
	  }
	  if (user->class == 1) {
	      mvprintw(30, 2, "   Rodney the Barbarian ");
	  }
	  if (user->class == 2) {
	      mvprintw(30, 2, "    Rodney the Cleric   ");
	  }
	  if (user->class == 3) {
 	     mvprintw(30, 2, "   Rodney the Fighter   ");
	  }
	  if (user->class == 4) {
	      mvprintw(30, 2, "   Rodney the Paladin   ");
	  }
	  if (user->class == 5) {
	      mvprintw(30, 2, "    Rodney the Rogue    ");
	  }
	  if (user->class == 6) {
	      mvprintw(30, 2, "    Rodney the Sorcerer  ");
	  }
	  if (user->class == 7) {
	      mvprintw(30, 2, "   Rodney the Wizard    ");
	  }
  attroff(COLOR_PAIR(1));
  }
  if (user->hp <= user->maxhp - 1)
  {
	  init_pair(11,COLOR_BLACK, COLOR_YELLOW);
	  attron(COLOR_PAIR(11));
	  if (user->class == 8) {
	      mvprintw(30, 2, "       Choose Class    ");
	  }
	  if (user->class == 1) {
	      mvprintw(30, 2, "   Rodney the Barbarian ");
	  }
	  if (user->class == 2) {
	      mvprintw(30, 2, "    Rodney the Cleric   ");
	  }
	  if (user->class == 3) {
 	     mvprintw(30, 2, "   Rodney the Fighter   ");
	  }
	  if (user->class == 4) {
	      mvprintw(30, 2, "   Rodney the Paladin   ");
	  }
	  if (user->class == 5) {
	      mvprintw(30, 2, "    Rodney the Rogue    ");
	  }
	  if (user->class == 6) {
	      mvprintw(30, 2, "    Rodney the Sorcerer  ");
	  }
	  if (user->class == 7) {
	      mvprintw(30, 2, "   Rodney the Wizard    ");
	  }
  attroff(COLOR_PAIR(11));
  }
  if (user->hp == 1)
  {
	  init_pair(13,COLOR_BLACK, COLOR_RED);
	  attron(COLOR_PAIR(13));
	  if (user->class == 8) {
	      mvprintw(30, 2, "       Choose Class    ");
	  }
	  if (user->class == 1) {
	      mvprintw(30, 2, "   Rodney the Barbarian ");
	  }
	  if (user->class == 2) {
	      mvprintw(30, 2, "    Rodney the Cleric   ");
	  }
	  if (user->class == 3) {
 	     mvprintw(30, 2, "   Rodney the Fighter   ");
	  }
	  if (user->class == 4) {
	      mvprintw(30, 2, "   Rodney the Paladin   ");
	  }
	  if (user->class == 5) {
	      mvprintw(30, 2, "    Rodney the Rogue    ");
	  }
	  if (user->class == 6) {
	      mvprintw(30, 2, "    Rodney the Sorcerer  ");
	  }
	  if (user->class == 7) {
	      mvprintw(30, 2, "   Rodney the Wizard    ");
	  }
  attroff(COLOR_PAIR(13));
  }
}



int race(Position * newPosition, Player * user, char ** level)
{
	mvprintw(31, 43, "Race: ");

  if (user->race == 8) {
      init_pair(2,COLOR_WHITE, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "CHOOSERACE");
      attroff(COLOR_PAIR(2));
    }

  if (user->race == 1) {
      init_pair(2,COLOR_GREEN, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "Orc       ");
      attroff(COLOR_PAIR(2));
    }

  if (user->race == 2) {
      init_pair(2,COLOR_YELLOW, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "Dragonborn");
      attroff(COLOR_PAIR(2));
    }

  if (user->race == 3) {
      init_pair(2,COLOR_RED, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "Dwarf      ");
      attroff(COLOR_PAIR(2));
    }

  if (user->race == 4) {
      init_pair(2,COLOR_CYAN, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "Elf        ");
      attroff(COLOR_PAIR(2));
    }

  if (user->race == 5) {
      init_pair(2,COLOR_MAGENTA, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "Gith       ");
      attroff(COLOR_PAIR(2));
    }

  if (user->race == 6) {
      init_pair(2,COLOR_BLUE, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "Hobbit     ");
      attroff(COLOR_PAIR(2));
    }

  if (user->race == 7) {
      init_pair(2,COLOR_WHITE, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 49, "Human      ");
      attroff(COLOR_PAIR(2));
    }

  // alignment

  if (user->race == 1) {
    user->alignment = 1;
  }

  if (user->race == 2) {
    user->alignment = 2;
  }

  if (user->race == 3) {
    user->alignment = 2;
  }

  if (user->race == 4) {
    user->alignment = 1;
  }

  if (user->race == 5) {
    user->alignment = 2;
  }

  if (user->race == 6) {
    user->alignment = 2;
  }

  if (user->race == 7) {
    user->alignment = 0;
  }


  if (user->alignment == 0) {
      mvprintw(31, 63, "Neutral  ");
    }

  if (user->alignment == 1) {
      mvprintw(31, 63, "Chaotic  ");
    }

  if (user->alignment == 2) {
      mvprintw(31, 63, "Lawful  ");
    } 

  // if player is NoClass
  if (user->class == 8) {
    user->b_strength = 10;
    user->b_dexterity = 10;
    user->b_constitution = 10;
    user->b_intelligence = 10;
    user->b_wisdom = 10;
    user->b_charisma = 10;
  }

  // if player is a Barbarian
  if (user->class == 1) {
    user->b_strength = 16;
    user->b_dexterity = 13;
    user->b_constitution = 14;
    user->b_intelligence = 10;
    user->b_wisdom = 12;
    user->b_charisma = 10;
  }

  // if player is a Cleric
  if (user->class == 2) {
    user->b_strength = 14;
    user->b_dexterity = 10;
    user->b_constitution = 13;
    user->b_intelligence = 10;
    user->b_wisdom = 15;
    user->b_charisma = 12;
  }

  // if player is a Fighter
  if (user->class == 3) {
    user->b_strength = 15;
    user->b_dexterity = 15;
    user->b_constitution = 13;
    user->b_intelligence = 10;
    user->b_wisdom = 12;
    user->b_charisma = 10;
  }

  // if player is a Paladin
  if (user->class == 4) {
    user->b_strength = 15;
    user->b_dexterity = 10;
    user->b_constitution = 13;
    user->b_intelligence = 10;
    user->b_wisdom = 12;
    user->b_charisma = 14;
  }

  // if player is a Rogue
  if (user->class == 5) {
    user->b_strength = 10;
    user->b_dexterity = 16;
    user->b_constitution = 10;
    user->b_intelligence = 13;
    user->b_wisdom = 12;
    user->b_charisma = 14;
  }

  // if player is a Wizard
  if (user->class == 6) {
    user->b_strength = 10;
    user->b_dexterity = 13;
    user->b_constitution = 14;
    user->b_intelligence = 16;
    user->b_wisdom = 12;
    user->b_charisma = 10;
  }

  // if player is a Sorcerer
  if (user->class == 7) {
    user->b_strength = 10;
    user->b_dexterity = 13;
    user->b_constitution = 14;
    user->b_intelligence = 10;
    user->b_wisdom = 12;
    user->b_charisma = 15;
  }


    // if player is a NoRace
      if (user->race == 8) {
        user->strength = user->b_strength;
        user->dexterity = user->b_dexterity;
        user->constitution = user->b_constitution;
        user->intelligence = user->b_intelligence;
        user->wisdom = user->b_wisdom;
        user->charisma = user->b_charisma;
      }

    // if player is a Orc
      if (user->race == 1) {
        user->strength = user->b_strength + 2;
        user->dexterity = user->b_dexterity;
        user->constitution = user->b_constitution + 2;
        user->intelligence = user->b_intelligence - 2;
        user->wisdom = user->b_wisdom;
        user->charisma = user->b_charisma;
      }

    // if player is a Dragonborn
      if (user->race == 2) {
        user->strength = user->b_strength + 2;
        user->dexterity = user->b_dexterity;
        user->constitution = user->b_constitution;
        user->intelligence = user->b_intelligence;
        user->wisdom = user->b_wisdom;
        user->charisma = user->b_charisma + 1;
      }

      // if player is a Dwarf
        if (user->race == 3) {
        user->strength = user->b_strength + 2;
        user->dexterity = user->b_dexterity;
        user->constitution = user->b_constitution;
        user->intelligence = user->b_intelligence;
        user->wisdom = user->b_wisdom + 1;
        user->charisma = user->b_charisma;
      }

      // if player is a Elf
        if (user->race == 4) {
          user->strength = user->b_strength;
          user->dexterity = user->b_dexterity + 2;
          user->constitution = user->b_constitution;
          user->intelligence = user->b_intelligence + 1;
          user->wisdom = user->b_wisdom;
          user->charisma = user->b_charisma;
        }

      // if player is a Gith
        if (user->race == 5) {
          user->strength = user->b_strength + 1;
          user->dexterity = user->b_dexterity;
          user->constitution = user->b_constitution;
          user->intelligence = user->b_intelligence + 1;
          user->wisdom = user->b_wisdom + 1;
          user->charisma = user->b_charisma;
        }

        // if player is a Hobbit
          if (user->race == 6) {
          user->strength = user->b_strength;
          user->dexterity = user->b_dexterity + 2;
          user->constitution = user->b_constitution;
          user->intelligence = user->b_intelligence;
          user->wisdom = user->b_wisdom;
          user->charisma = user->b_charisma + 1;
        }

        // if player is a Human
          if (user->race == 7) {
          user->strength = user->b_strength + 1;
          user->dexterity = user->b_dexterity + 1;
          user->constitution = user->b_constitution + 1;
          user->intelligence = user->b_intelligence + 1;
          user->wisdom = user->b_wisdom + 1;
          user->charisma = user->b_charisma + 1;
        }

    // stat mods
    user->strMod = ((user->strength - 10) / 2);
    user->dexMod = ((user->dexterity - 10) / 2);
    user->conMod = ((user->constitution - 10) / 2);
    user->intMod = ((user->intelligence - 10) / 2);
    user->wisMod = ((user->wisdom - 10) / 2);
    user->chaMod = ((user->charisma - 10) / 2);

    // HP at first level
if (user->class == 8) {
  user->maxhp = (6 + user->conMod);
}

if (user->class == 1) {
  user->maxhp = (12 + user->conMod); 
}

if (user->class == 2) {
  user->maxhp = (8 + user->conMod); 
}

if (user->class == 3) {
  user->maxhp = (10 + user->conMod); 
}

if (user->class == 4) {
  user->maxhp = (10 + user->conMod); 
}

if (user->class == 5) {
  user->maxhp = (8 + user->conMod); 
}

if (user->class == 6) {
  user->maxhp = (6 + user->conMod); 
}

if (user->class == 7) {
  user->maxhp = (6 + user->conMod);
}

    // HP and higher levels
if (user->level > 1) {
  if (user->class == 1) {
    user->maxhp = ((7 + user->conMod) * user->level);
  }

  if (user->class == 2) {
    user->maxhp = ((5 + user->conMod) * user->level);
  }

  if (user->class == 3) {
    user->maxhp = ((6 + user->conMod) * user->level);
  }

  if (user->class == 4) {
    user->maxhp = ((6 + user->conMod) * user->level);
  }

  if (user->class == 5) {
    user->maxhp = ((5 + user->conMod) * user->level);
  }

  if (user->class == 6) {
    user->maxhp = ((4 + user->conMod) * user->level);
  }

  if (user->class == 7) {
    user->maxhp = ((4 + user->conMod) * user->level);
  }
  }

  if (user->race == 3) {
	user->maxhp = ((user->maxhp) + (1 * user->level));
	}

  user->armor = 1;

  // Armor Class
   user->ac = ((10 + user->dexMod) + (user->armorBonus + user->acMagic));

  // Barbarian's Unarmored Defense
  if (user->class == 1) {
    user->ac = ((10 + user->conMod) + user->dexMod);
}
  if (user->position.x == 15)
  {
	if (user->position.y == 15)
	{
  	  user->hp = user->maxhp;
	}
  }

  if (user->position.x == 35)
  {
	if (user->position.y == 17)
	{
  	  user->hp = user->maxhp;
	}
  }

  // Set current to max hp
  user->hp = user->maxhp;
  mvprintw(30, 1, "[                        ]");

  raw();
  start_color();
  init_pair(1,COLOR_BLACK, COLOR_GREEN);
  attron(COLOR_PAIR(1));

  if (user->class == 8) {
  mvprintw(30, 2, "       Choose Class    ");
	  }
	  if (user->class == 1) {
	      mvprintw(30, 2, "   Rodney the Barbarian ");
	  }
	  if (user->class == 2) {
	      mvprintw(30, 2, "    Rodney the Cleric   ");
	  }
	  if (user->class == 3) {
 	     mvprintw(30, 2, "   Rodney the Fighter   ");
	  }
	  if (user->class == 4) {
	      mvprintw(30, 2, "   Rodney the Paladin   ");
	  }
	  if (user->class == 5) {
	      mvprintw(30, 2, "    Rodney the Rogue    ");
	  }
	  if (user->class == 6) {
	      mvprintw(30, 2, "    Rodney the Sorcerer  ");
	  }
	  if (user->class == 7) {
	      mvprintw(30, 2, "   Rodney the Wizard    ");
	  }
  attroff(COLOR_PAIR(1));



  mvprintw(30, 29, "Str:%d(%d)", user->strength, user->strMod);
  mvprintw(30, 40, "Dex:%d(%d)", user->dexterity, user->dexMod);
  mvprintw(30, 51, "Con:%d(%d)", user->constitution, user->conMod);
  mvprintw(30, 62, "Int:%d(%d)", user->intelligence, user->intMod);
  mvprintw(30, 73, "Wis:%d(%d)", user->wisdom, user->wisMod);
  mvprintw(30, 84, "Cha:%d(%d)", user->charisma, user->chaMod);

  mvprintw(31, 1, "HP: %d(%d)  ", user->hp, user->maxhp);

  mvprintw(31, 13, "Level: %d", user->level);
  mvprintw(31, 23, "AC: %d", user->ac);

  mvprintw(31, 31, "Gold: %d", user->gold);

//  if (user->class == 2)
//  {
  mvprintw(32, 20, "Spell Slots: %d", user->spellSlot);
//  }
  
//  if (user->class == 5)
//  {
//  mvprintw(32, 20, "Spell Slots: %d", user->spellSlot);
//  }

  if (user->race == 1)
  {  
  	if (user->class == 1)
  	{
	   mvprintw(32, 1, "Axe of Gruumsh");
	}  
  	if (user->class == 2)
  	{  
	   mvprintw(32, 1, "Nutured one of Yurtrus");
	}
  } 
  if (user->race == 2)
  {  
  	if (user->class == 2)
  	{
	   mvprintw(32, 1, "Priest of Tiamat");
	}  
  	if (user->class == 4)
  	{  
	   mvprintw(32, 1, "Shield of Bahamut");
	}
  }
  if (user->race == 3)
  {  
  	if (user->class == 2)
  	{
	   mvprintw(32, 1, "Cleric of Odin");
	}  
  	if (user->class == 4)
  	{  
	   mvprintw(32, 1, "Soldier of Moradin");
	}
  }
  if (user->race == 4)
  {  
  	if (user->class == 2)
  	{
	   mvprintw(32, 1, "Blessed of Corellon");
	}  
  	if (user->class == 4)
  	{  
	   mvprintw(32, 1, "Eldritch Knight of Corellon");
	}
  }
  if (user->race == 6)
  {  
  	if (user->class == 2)
  	{
	   mvprintw(32, 1, "Priest of Yondalla");
	}  
  	if (user->class == 4)
  	{  
	   mvprintw(32, 1, "Braveheart of Yondalla");
	} 
  }
  if (user->race == 7)
  {  
  	if (user->class == 2)
  	{
	   mvprintw(32, 1, "Cleric of Tyr");
	}  
  	if (user->class == 4)
  	{  
	   mvprintw(32, 1, "Warrior of Tyr");
	}
}

int startHealth(Player * user, char ** level)
{
  user->hp = user->maxhp;
  mvprintw(31, 1, "HP: %d(%d)  ", user->hp, user->maxhp);
}
}


