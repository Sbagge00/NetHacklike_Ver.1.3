#include "rogue.h"
#include "windows/mainMenu.h"

void menuLoop(Player * user)
{
    int choice;
    char * choices[] = {"Start Game", "End"};

    while (true)
    {
        choice = mainMenu(2, choices);

        switch (choice)
        {
            case START_GAME:
                menuLoop(user);
		clear();
                break;
            case END_GAME:
                return;
                break;
        }
    }
}

int main()
{
  
  Player * user;
  Player * hp;
  int ch;
  Position * newPosition;

  char ** level;

  screenSetUp();
  //    printGameHub(level);;

  char * choices[] = {"Start Game", "End Game"};

  mainMenu(2, choices);

  user = playerSetUp();

  chooseRaceScreen();
  
  chooseClassScreen();

  lvlOne();

  level = saveLevelPositions();
  



/* main game loop */
  while ((ch = getch()) != 'Q')
  {
     // printGameHub(level);
      selectCharacter(ch, user, level);
      newPosition = handleInput(ch, user, level);
      checkPosition(newPosition, user, level);

	if (user->hp <= 0)
	{
	    clear();
	    screenGameOver(user);
	}
  }
  endwin();

  return 0;
}
