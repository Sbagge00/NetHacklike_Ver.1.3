#include "rogue.h"

Player * playerSetUp()
{
  Player * newPlayer;
  newPlayer = malloc(sizeof(Player));

  newPlayer->position.x = 15;
  newPlayer->position.y = 15;
  newPlayer->acMagic = 0;
  newPlayer->armor = 1;

  //races
  newPlayer->race = 8;
  /*  8 NoRace
      1 Orc
      2 Dragonborn
      3 Dwarf
      4 Elf
      5 Gith
      6 Hobbit
      7 Human       */

  // class level
  newPlayer->level = 1;

  newPlayer->spellSlot = (((1 * newPlayer->level) / 2) + 1);

  // class
  newPlayer->class = 8;
  /*  8 NoClass
      1 Barbarian
      2 Cleric
      3 Fighter
      4 Paladin
      5 Rogue
      6 Sorcerer
      7 Wizard     */


  newPlayer->gold = 0;

  // alignment
  /*
  if (newPlayer->race == 1) {
    newPlayer->alignment = 1;
  }

  if (newPlayer->race == 2) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 3) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 4) {
    newPlayer->alignment = 1;
  }

  if (newPlayer->race == 5) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 6) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 7) {
    newPlayer->alignment = 0;
  } */

  // if player is a NoClass
  if (newPlayer->class == 8) {
    newPlayer->b_strength = 10;
    newPlayer->b_dexterity = 10;
    newPlayer->b_constitution = 10;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 10;
    newPlayer->b_charisma = 10;
  }

  // if player is a Barbarian
  if (newPlayer->class == 1) {
    newPlayer->b_strength = 16;
    newPlayer->b_dexterity = 13;
    newPlayer->b_constitution = 14;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 10;
  }

  // if player is a Cleric
  if (newPlayer->class == 2) {
    newPlayer->b_strength = 14;
    newPlayer->b_dexterity = 10;
    newPlayer->b_constitution = 13;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 15;
    newPlayer->b_charisma = 12;
  }

  // if player is a Fighter
  if (newPlayer->class == 3) {
    newPlayer->b_strength = 15;
    newPlayer->b_dexterity = 15;
    newPlayer->b_constitution = 13;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 10;
  }

  // if player is a Paladin
  if (newPlayer->class == 4) {
    newPlayer->b_strength = 15;
    newPlayer->b_dexterity = 10;
    newPlayer->b_constitution = 13;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 14;
  }

  // if player is a Rogue
  if (newPlayer->class == 5) {
    newPlayer->b_strength = 10;
    newPlayer->b_dexterity = 16;
    newPlayer->b_constitution = 10;
    newPlayer->b_intelligence = 13;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 14;
  }

  // if player is a Wizard
  if (newPlayer->class == 6) {
    newPlayer->b_strength = 10;
    newPlayer->b_dexterity = 13;
    newPlayer->b_constitution = 14;
    newPlayer->b_intelligence = 16;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 10;
  }

  // if player is a Sorcerer
  if (newPlayer->class == 7) {
    newPlayer->b_strength = 10;
    newPlayer->b_dexterity = 13;
    newPlayer->b_constitution = 14;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 15;
  }
    // if player is a NoRace
      if (newPlayer->race == 8) {
        newPlayer->strength = newPlayer->b_strength;
        newPlayer->dexterity = newPlayer->b_dexterity;
        newPlayer->constitution = newPlayer->b_constitution;
        newPlayer->intelligence = newPlayer->b_intelligence;
        newPlayer->wisdom = newPlayer->b_wisdom;
        newPlayer->charisma = newPlayer->b_charisma;
      }

    // if player is a Orc
      if (newPlayer->race == 1) {
        newPlayer->strength = newPlayer->b_strength + 2;
        newPlayer->dexterity = newPlayer->b_dexterity;
        newPlayer->constitution = newPlayer->b_constitution + 2;
        newPlayer->intelligence = newPlayer->b_intelligence - 2;
        newPlayer->wisdom = newPlayer->b_wisdom;
        newPlayer->charisma = newPlayer->b_charisma;
      }

    // if player is a Dragonborn
      if (newPlayer->race == 2) {
        newPlayer->strength = newPlayer->b_strength + 2;
        newPlayer->dexterity = newPlayer->b_dexterity;
        newPlayer->constitution = newPlayer->b_constitution;
        newPlayer->intelligence = newPlayer->b_intelligence;
        newPlayer->wisdom = newPlayer->b_wisdom;
        newPlayer->charisma = newPlayer->b_charisma + 1;
      }

      // if player is a Dwarf
        if (newPlayer->race == 3) {
        newPlayer->strength = newPlayer->b_strength;
        newPlayer->dexterity = newPlayer->b_dexterity;
        newPlayer->constitution = newPlayer->b_constitution + 2;
        newPlayer->intelligence = newPlayer->b_intelligence;
        newPlayer->wisdom = newPlayer->b_wisdom + 1;
        newPlayer->charisma = newPlayer->b_charisma;
      }

      // if player is a Elf
        if (newPlayer->race == 4) {
          newPlayer->strength = newPlayer->b_strength;
          newPlayer->dexterity = newPlayer->b_dexterity + 2;
          newPlayer->constitution = newPlayer->b_constitution;
          newPlayer->intelligence = newPlayer->b_intelligence + 1;
          newPlayer->wisdom = newPlayer->b_wisdom;
          newPlayer->charisma = newPlayer->b_charisma;
        }

      // if player is a Gith
        if (newPlayer->race == 5) {
          newPlayer->strength = newPlayer->b_strength + 1;
          newPlayer->dexterity = newPlayer->b_dexterity;
          newPlayer->constitution = newPlayer->b_constitution;
          newPlayer->intelligence = newPlayer->b_intelligence + 1;
          newPlayer->wisdom = newPlayer->b_wisdom + 1;
          newPlayer->charisma = newPlayer->b_charisma;
        }

        // if player is a Hobbit
          if (newPlayer->race == 6) {
          newPlayer->strength = newPlayer->b_strength;
          newPlayer->dexterity = newPlayer->b_dexterity + 2;
          newPlayer->constitution = newPlayer->b_constitution;
          newPlayer->intelligence = newPlayer->b_intelligence;
          newPlayer->wisdom = newPlayer->b_wisdom;
          newPlayer->charisma = newPlayer->b_charisma + 1;
        }

        // if player is a Human
          if (newPlayer->race == 7) {
          newPlayer->strength = newPlayer->b_strength + 1;
          newPlayer->dexterity = newPlayer->b_dexterity + 1;
          newPlayer->constitution = newPlayer->b_constitution + 1;
          newPlayer->intelligence = newPlayer->b_intelligence + 1;
          newPlayer->wisdom = newPlayer->b_wisdom + 1;
          newPlayer->charisma = newPlayer->b_charisma + 1;
        }

    // stat mods
    newPlayer->strMod = ((newPlayer->strength - 10) / 2);
    newPlayer->dexMod = ((newPlayer->dexterity - 10) / 2);
    newPlayer->conMod = ((newPlayer->constitution - 10) / 2);
    newPlayer->intMod = ((newPlayer->intelligence - 10) / 2);
    newPlayer->wisMod = ((newPlayer->wisdom - 10) / 2);
    newPlayer->chaMod = ((newPlayer->charisma - 10) / 2);

    // HP at first level
if (newPlayer->class == 8) {
  newPlayer->maxhp = (6 + newPlayer->conMod);
}

if (newPlayer->class == 1) {
  newPlayer->maxhp = (12 + newPlayer->conMod);
}

if (newPlayer->class == 2) {
  newPlayer->maxhp = (8 + newPlayer->conMod);
}

if (newPlayer->class == 3) {
  newPlayer->maxhp = (10 + newPlayer->conMod);
}

if (newPlayer->class == 4) {
  newPlayer->maxhp = (10 + newPlayer->conMod);
}

if (newPlayer->class == 5) {
  newPlayer->maxhp = (8 + newPlayer->conMod);
}

if (newPlayer->class == 6) {
  newPlayer->maxhp = (6 + newPlayer->conMod);
}

if (newPlayer->class == 7) {
  newPlayer->maxhp = (6 + newPlayer->conMod);
}

    // HP and higher levels
if (newPlayer->level > 1) {
  if (newPlayer->class == 8) {
    newPlayer->maxhp = ((6 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 1) {
    newPlayer->maxhp = ((7 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 2) {
    newPlayer->maxhp = ((5 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 3) {
    newPlayer->maxhp = ((6 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 4) {
    newPlayer->maxhp = ((6 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 5) {
    newPlayer->maxhp = ((5 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 6) {
    newPlayer->maxhp = ((4 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 7) {
    newPlayer->maxhp = ((4 + newPlayer->conMod) * newPlayer->level);
  }

}

  // Setting current hp to max hp at start of game
  newPlayer->hp = newPlayer->maxhp;

  // Armor Class
  newPlayer->ac = ((10 + newPlayer->dexMod) + (newPlayer->armorBonus + newPlayer->acMagic));

  // Barbarian's Unarmored Defense
  if (newPlayer->class == 1) {
    newPlayer->ac = ((10 + newPlayer->conMod) + newPlayer->dexMod);
  }

  mvprintw(newPlayer->position.y, newPlayer->position.x, "@");
  move(newPlayer->position.y, newPlayer->position.x);

  mvprintw(30, 1, "[                        ]");

  raw();
  start_color();
  init_pair(1,COLOR_BLACK, COLOR_GREEN);
  attron(COLOR_PAIR(1));

  if (newPlayer->class == 0) {
      mvprintw(30, 2, "    Choose Race/Class   ");
  }

  if (newPlayer->class == 1) {
      mvprintw(30, 2, "     Rodney Barbarian   ");
  }

  if (newPlayer->class == 2) {
      mvprintw(30, 2, "    Rodney the Cleric   ");
  }

  if (newPlayer->class == 3) {
      mvprintw(30, 2, "   Rodney the Fighter   ");
  }

  if (newPlayer->class == 4) {
      mvprintw(30, 2, "   Rodney the Paladin   ");
  }

  if (newPlayer->class == 5) {
      mvprintw(30, 2, "    Rodney the Rogue    ");
  }

  if (newPlayer->class == 6) {
      mvprintw(30, 2, "    Rodney the Wizard   ");
  }

  if (newPlayer->class == 7) {
      mvprintw(30, 2, "  Rodney the Sorcerer   ");
  }


  attroff(COLOR_PAIR(1));
/*
  mvprintw(30, 29, "STR: %d(%d)", newPlayer->strength, newPlayer->strMod);
  mvprintw(30, 41, "DEX: %d(%d)", newPlayer->dexterity, newPlayer->dexMod);
  mvprintw(30, 54, "CON: %d(%d)", newPlayer->constitution, newPlayer->conMod);
  mvprintw(30, 67, "INT: %d(%d)", newPlayer->intelligence, newPlayer->intMod);
  mvprintw(30, 79, "WIS: %d(%d)", newPlayer->wisdom, newPlayer->wisMod);
  mvprintw(30, 92, "CHA: %d(%d)", newPlayer->charisma, newPlayer->chaMod);

  mvprintw(31, 1, "HP: %d(%d)", newPlayer->hp, newPlayer->maxhp);

  mvprintw(31, 13, "Level: %d", newPlayer->level);
  mvprintw(31, 23, "AC: %d", newPlayer->ac);
*/
  
  return newPlayer;
}

Position * handleInput(int input, Player * user, char ** level)
{
  Position * newPosition;
  newPosition = malloc(sizeof(Position));

  switch (input)
  {
    /* move up */
    case '8':
    case KEY_UP:    
 	mvprintw(1, 0, "                                                                ");  
 	mvprintw(2, 0, "                                                                ");  
	newPosition->x = user->position.x;
        newPosition->y = user->position.y - 1;
	checkTrapsUp(newPosition, user, level);
        break;

    /* move down */
    case '2':
    case KEY_DOWN:
 	mvprintw(1, 0, "                                                                ");  
 	mvprintw(2, 0, "                                                                ");  
        newPosition->y = user->position.y + 1;
        newPosition->x = user->position.x;
	checkTrapsDown(newPosition, user, level);
        break;

    /* move left */
    case '4':
    case KEY_LEFT: 
 	mvprintw(1, 0, "                                                                ");  
 	mvprintw(2, 0, "                                                                ");  
        newPosition->y = user->position.y;
        newPosition->x = user->position.x - 1;
	checkTrapsLeft(newPosition, user, level);
	secretDoorLeft(newPosition, user, level);
        break;

    /* move right */
    case '6':
    case KEY_RIGHT:
 	mvprintw(1, 0, "                                                                ");  
 	mvprintw(2, 0, "                                                                ");  
        newPosition->y = user->position.y;
        newPosition->x = user->position.x + 1;
	checkTrapsRight(newPosition, user, level);
	secretDoorRight(newPosition, user, level);
        break;

    /* diagonal up left */
    case '7':
	if (user->race == 6)
	{
 	  mvprintw(1, 0, "                                                                ");  
 	  mvprintw(2, 0, "                                                                ");  
          newPosition->y = user->position.y - 1;
          newPosition->x = user->position.x - 1;
	  mvprintw(1, 0, "You move nimbly with your small form! ");
	}        
	break;

    /* diagonal up right */
    case '9':
	if (user->race == 6)
	{
 	  mvprintw(1, 0, "                                                                ");  
 	mvprintw(2, 0, "                                                                ");  
          newPosition->y = user->position.y - 1;
          newPosition->x = user->position.x + 1;
	  mvprintw(1, 0, "You move nimbly with your small form! ");
	}
        break;

    /* diagonal down left */
    case '1':
	if (user->race == 6)
	{
 	  mvprintw(1, 0, "                                                                ");  
 	mvprintw(2, 0, "                                                                ");  
          newPosition->y = user->position.y + 1;
          newPosition->x = user->position.x - 1;
	  mvprintw(1, 0, "You move nimbly with your small form! ");
	}
        break;

    /* diaganol down right */
    case '3':
	if (user->race == 6)
	{
 	mvprintw(1, 0, "                                                                ");  
 	mvprintw(2, 0, "                                                                ");  
        newPosition->y = user->position.y + 1;
        newPosition->x = user->position.x + 1;
	  mvprintw(1, 0, "You move nimbly with your small form! ");
	}
        break;

		// COMMANDS
     case 'y':
	if (user->position.y == 15, user->position.x == 21)
	{    
   	   int num;	
	   srand(time(0));
  	   num = rand() % 100 + 1;
           if (num <= (5 + user->level))
	   {
             mvprintw(2, 0, "There is a rusted sword in the water! You pick it up.             ");
   	   } else {
	     mvprintw(2, 0, "The water is satisfying.                                         ");
	   }
	}
	if (user->position.y == 6, user->position.x == 44)
	{
	   mvprintw(1, 0, "You follow the stairs downwards...                               ");
	   lvlTwo();
	   user->position.x = 26;
 	   user->position.y = 6;
	}
	if (user->position.y == 12, user->position.x == 56)
	{
	   mvprintw(1, 0, "You loot the gold!                                              ");	   
           user->gold = user->gold + 5;
	   race(newPosition, user, level);
 	   user->position.x = 56;
	   user->position.y = 11;
	   mvprintw(12, 56, ".");
	}
	break;

    case 'n':
	if (user->position.y == 15, user->position.x == 21)
	{    
	   mvprintw(1, 0, "You decide not to drink any water...                             ");     
	}
	if (user->position.y == 6, user->position.x == 44)
	{
	   mvprintw(1, 0, "You decide not to traverse the darkness below...                 ");
	}
	if (user->position.y == 12, user->position.x == 56)
	{
	   mvprintw(1, 0, "You leave the gold.                                           ");
 	   user->position.x = 56;
  	   user->position.y = 11;
	   mvprintw(12, 56, ".");
	}
	break;

		// SPELLS
    case 'Z':
	if (user->class == 2)
	{    
	  if (user->spellSlot >= 1) 
	  {
  	    mvprintw(1, 0, "You cast a miracle! Energy pulses through you!");
	    spellHealingWork(newPosition, user, level);
	    user->spellSlot = user->spellSlot - 1;
	  }
	}
	if (user->class == 4)
	{    
	  if (user->spellSlot >= 1) 
	  {
   	    mvprintw(1, 0, "You cast a spell and a glowing shield hovers next to you!");
	    user->acMagic = 2;
	    user->spellSlot -= 1;
	    race(newPosition, user, level);
	  }
	}
	if (user->class == 6)
	{    
	  if (user->spellSlot >= 1) 
	  {
   	    mvprintw(1, 0, "You cast a spell and a clap of thunder eminates from you!");
   	    mvprintw(user->position.y -1, user->position.x, "T");
   	    mvprintw(user->position.y -1, user->position.x +1, "T");
   	    mvprintw(user->position.y -1, user->position.x -1, "T");
   	    mvprintw(user->position.y, user->position.x +1, "T");
   	    mvprintw(user->position.y, user->position.x -1, "T");
   	    mvprintw(user->position.y +1, user->position.x, "T");
   	    mvprintw(user->position.y +1, user->position.x +1, "T");
   	    mvprintw(user->position.y +1, user->position.x -1, "T");

   	    mvprintw(user->position.y -2, user->position.x, "T");
   	    mvprintw(user->position.y -2, user->position.x +1, "T");
   	    mvprintw(user->position.y -2, user->position.x -1, "T");

   	    mvprintw(user->position.y +1, user->position.x -2, "T");
   	    mvprintw(user->position.y, user->position.x -2, "T");
   	    mvprintw(user->position.y -1, user->position.x -2, "T");

   	    mvprintw(user->position.y +2, user->position.x +1, "T");
   	    mvprintw(user->position.y +2, user->position.x, "T");
   	    mvprintw(user->position.y +2, user->position.x -1, "T");

   	    mvprintw(user->position.y +1, user->position.x +2, "T");
   	    mvprintw(user->position.y, user->position.x +2, "T");
   	    mvprintw(user->position.y -1, user->position.x +2, "T");

   	    mvprintw(user->position.y, user->position.x -3, "T");
   	    mvprintw(user->position.y, user->position.x +3, "T");

	    lvlOne();
	    
	    user->spellSlot -= 1;
	    race(newPosition, user, level);
	  }
	}
	if (user->class == 7)
	{    
	  if (user->spellSlot >= 1) 
	  {
   	    mvprintw(1, 0, "You cast a spell and a clap of thunder eminates from you!");
	    user->spellSlot -= 1;
	    race(newPosition, user, level);
	  }
	}

	break;

	        // DRAGONBORN BREATH ATTACK
    case 'b':
	if (user->race == 2)
	{
	    mvprintw(1, 0, "You release your breath weapon attack!");
   	    mvprintw(user->position.y, user->position.x -1, "<");
   	    mvprintw(user->position.y -1, user->position.x -2, "<");
   	    mvprintw(user->position.y, user->position.x -2, "<");
   	    mvprintw(user->position.y +1, user->position.x -2, "<");
   	    mvprintw(user->position.y -2, user->position.x -3, "<");
   	    mvprintw(user->position.y -1, user->position.x -3, "<");
   	    mvprintw(user->position.y, user->position.x -3, "<");
   	    mvprintw(user->position.y +1, user->position.x -3, "<");
   	    mvprintw(user->position.y +2, user->position.x -3, "<");
	 }
	break;

		// CLIMB
    case 'c':
	if(user->position.y != 18, user->position.x != 29)
        {
	   mvprintw(1, 0, "There is nothing to climb out of...                             ");     
	} else {     
	   clear();
	   lvlOne();
	   mvprintw(0, 0, "                                                              ");
	   mvprintw(1, 0, "You climb out of the pit!                                       ");
	   race(newPosition, user, level);
	user->hp -= 7;
 	mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
           health(newPosition, user, level);
	}
	break;
		// LOOT
   case 'l':
	if(user->position.y == 12, user->position.x == 56)
        {
	   mvprintw(1, 0, "There is gold here. Loot? [y/n]                             ");     
	}
	break;

	 	// LONG REST
   case 'r':
	mvprintw(1, 0, "You take a long rest...                             "); 
	int num;	
	srand(time(0));
  	num = rand() % 100 + 1;
	   if (num >= (70 + (user->wisMod + user->level))){
	     user->hp = 1;
 	     mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
             health(newPosition, user, level);
	     mvprintw(2, 0, "You where attacked while sleeping! Your items have been stolen!");   
	   } else {  
	     spells(newPosition, user, level);
	     user->hp = user->maxhp;
	     race(newPosition, user, level);
	     mvprintw(2, 0, "You feel invigorated!                             ");   
	   }
	break;

		// WEAR
    case 'w':
	if (user->armorBonus == 4){
	   	mvprintw(1, 0, "You doff the Chain Shirt.                                           ");
		user->armorBonus = 0;
		race(newPosition, user, level);
		} else {
	   	mvprintw(1, 0, "You go to don the Chain Shirt.                                           ");
	   	if (user->class == 1) // barbarian
	  	{
		mvprintw(2, 0, "It's too small. You take it off.");
	   	}
	   	if (user->class == 2) // cleric
	   	{
		mvprintw(2, 0, "The armor fits nicely.");
		user->armorBonus = 4;
		race(newPosition, user, level);
	   	}
	   	if (user->class == 3) // fighter
	   	{
		mvprintw(3, 0, "The armor fits nicely.");
		user->armorBonus = 4;
		race(newPosition, user, level);
	   	}
	   	if (user->class == 4) // paladin
	   	{
		mvprintw(2, 0, "The armor fits nicely.");
		user->armorBonus = 4;
		race(newPosition, user, level);
	   	}
	   	if (user->class == 5) // rogue
	   	{
		mvprintw(2, 0, "You try to walk in it but it's too loud! You take it off.");
	   	}
	   	if (user->class == 6) // sorcerer
	   	{
		mvprintw(2, 0, "The armor makes it difficult to cast spells. You take it off.");
	   	}
	   	if (user->class == 7) // wizard
	   	{
		mvprintw(2, 0, "Such powerful minds need not feeble weaponry! You take it off.");
	   	}
		break;
		}
}
  return newPosition;

}

Player * selectCharacter(int input, Player * user, char ** level)
{
  Position * newPosition;
  newPosition = malloc(sizeof(Position));

  if (user->race < 8)
  {
	if (user->class == 8)
	{
	   raw();
	   start_color();
	   init_pair(12,COLOR_WHITE, COLOR_RED);
 	   attron(COLOR_PAIR(12));
	   mvprintw(0, 0, "Choose your character class!");
  	   attroff(COLOR_PAIR(12));
	}

} else {
    switch (input)
    {
    case 'o':
        user->race = 1;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'd':
        user->race = 2;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'D':
        user->race = 3;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'e':
        user->race = 4;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'g':
        user->race = 5;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'h':
        user->race = 6;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'H':
        user->race = 7;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;
    }
  }

  if (user->class < 8)
  {
	if (user->race == 8)
	{
	   raw();
	   start_color();
	   init_pair(12,COLOR_WHITE, COLOR_RED);
 	   attron(COLOR_PAIR(12));
	   mvprintw(0, 0, "Choose your character race!");
 	   attroff(COLOR_PAIR(12));
	}
  

} else {
    switch (input)
    {
    case 'B':
        user->class = 1;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'C':
        user->class = 2;
 	spells(newPosition, user, level);
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'F':
        user->class = 3;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'P':
        user->class = 4;
 	spells(newPosition, user, level);
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'R':
        user->class = 5;
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'S':
        user->class = 6;
 	spells(newPosition, user, level);
	race(newPosition, user, level);
//        startHealth(user, level);
        break;

    case 'W':
        user->class = 7;
 	spells(newPosition, user, level);
	race(newPosition, user, level);
//        startHealth(user, level);
        break;
    }
  }
}


/* check what is at next position */
int checkPosition(Position * newPosition, Player * user, char ** level)
{

    int space;
    switch (mvinch(newPosition->y, newPosition->x))
    {
        case '.':
        case '#':
        case '+':
	case 'T':
            mvprintw(0, 0, "                                                                  ");           
	    playerMove(newPosition, user, level);
	if (user->race == 8)
	{
	   raw();
	   start_color();
	   init_pair(12,COLOR_WHITE, COLOR_RED);
 	   attron(COLOR_PAIR(12));
	   mvprintw(0, 0, "Choose your character race!");
 	   attroff(COLOR_PAIR(12));
	}
	if (user->class == 8)
	{
	   raw();
	   start_color();
	   init_pair(12,COLOR_WHITE, COLOR_RED);
 	   attron(COLOR_PAIR(12));
	   mvprintw(0, 0, "Choose your character class!");
 	   attroff(COLOR_PAIR(12));
	}
            break;
        case 'o':
            mvprintw(0, 0, "                                                                  ");           
	    playerMove(newPosition, user, level);
	    lvlTrap(newPosition, user, level);
            break;
        case 'v':	    
            arrowTrap(newPosition, user, level);
            break;
	case '$':
	    mvprintw(1, 0, "Something shines on the floor...                             ");	    
//	    if (user->gold <= 95)
//	    {
//	    playerMove(newPosition, user, level);
//            user->gold = user->gold + 5;
//	    mvprintw(1, 0, "You found up some gold! ");
//	    race(newPosition,user, level);
//	    }
	    playerMove(newPosition, user, level);
            break;
	case '}':
	    playerMove(newPosition, user, level);
	    mvprintw(1, 0, "There is a fountain here. Would you like to drink from it? [y/n]");
            break;        
	case '>':
	    playerMove(newPosition, user, level);
	    mvprintw(1, 0, "Stairs lead downward. Continue? [y/n]");
            break;  
	case '^':
	    playerMove(newPosition, user, level);
	    if (user->level <= 19)
	    {
	    mvprintw(1, 0, "A mysterious power surges through you. You level up!             ");
	    spells(newPosition, user, level);
	    user->level = user->level + 1;
	    race(newPosition, user, level);
	    }
            break;
	default:
            mvprintw(0, 0, "                                                                   "); 
            move(user->position.y, user->position.x);
            break;
    }
}

int playerMove(Position * newPosition, Player * user, char ** level)
{

    char buffer[8];



    sprintf(buffer, "%c", level[user->position.y][user->position.x]);

    mvprintw(user->position.y, user->position.x, buffer);

    user->position.y = newPosition->y;
    user->position.x = newPosition->x;

    mvprintw(user->position.y, user->position.x, "@");
    move(user->position.y, user->position.x);

}
