#include "rogue.h"

/* making rooms and the map */

int checkTrapsUp(Position * newPosition, Player * user, char ** level)
{
  if (newPosition->y == 17)
  {
     if (newPosition->x == 18)
     {
  	mvprintw(user->position.y -1, user->position.x, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
  if (newPosition->y == 7)  // for second trap
  {
     if (newPosition->x == 31)
     {
  	mvprintw(user->position.y -1, user->position.x, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
}

int checkTrapsDown(Position * newPosition, Player * user, char ** level)
{
  if (newPosition->y == 17)
  {
     if (newPosition->x == 18)
     {
  	mvprintw(user->position.y +1, user->position.x, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
  if (newPosition->y == 7)
  {
     if (newPosition->x == 31)
     {
  	mvprintw(user->position.y +1, user->position.x, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
}

int checkTrapsLeft(Position * newPosition, Player * user, char ** level)
{
  if (newPosition->y == 17)
  {
     if (newPosition->x == 18)
     {
  	mvprintw(user->position.y, user->position.x -1, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
  if (newPosition->y == 7)
  {
     if (newPosition->x == 31)
     {
  	mvprintw(user->position.y, user->position.x -1, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
}

int checkTrapsRight(Position * newPosition, Player * user, char ** level)
{
  if (newPosition->y == 17)
  {
     if (newPosition->x == 18)
     {
  	mvprintw(user->position.y, user->position.x +1, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
  if (newPosition->y == 7)
  {
     if (newPosition->x == 31)
     {
  	mvprintw(user->position.y, user->position.x +1, "v");
  	mvprintw(newPosition->y, newPosition->x, "v");
     }
  }
}

int secretDoorLeft(Position * newPosition, Player * user, char ** level)
{
  if (newPosition->y == 9)
  {
     if (newPosition->x == 47)
     {
	mvprintw(1, 0, "Aha! A secret door...");
  	mvprintw(user->position.y, user->position.x -1, ".");
  	mvprintw(newPosition->y, newPosition->x, ".");
     }
  }
}

int secretDoorRight(Position * newPosition, Player * user, char ** level)
{
  if (newPosition->y == 9)
  {
     if (newPosition->x == 47)
     {
	mvprintw(1, 0, "Aha! A secret door...");
  	mvprintw(user->position.y, user->position.x +1, ".");
  	mvprintw(newPosition->y, newPosition->x, ".");
     }
  }
}

int lvlTrap(Position * newPosition, Player * user, char ** level)
{
  clear();
  mvprintw(0, 0, "You fell down a hole!");
  mvprintw(17, 28, "---");
  mvprintw(18, 28, "-@-");
  mvprintw(19, 28, "---");
  pitTrap(newPosition, user, level);
}

int lvlOne()
{
mvprintw(0, 0, "Choose race, then choose class.");

  mvprintw(5, 13, "-----------------------------------");
  mvprintw(6, 13, "|..............|...|...........>..|");
  mvprintw(7, 13, "|..............|...+..............|");
  mvprintw(8, 13, "|..............|...|..............|");
  mvprintw(9, 13, "|..............|...|..............|");
  mvprintw(10, 13, "|..............|...|..............|");
  mvprintw(11, 13, "-------+---------+-----------------");
  mvprintw(12, 13, "       ######    ##");

  mvprintw(10, 54, "---+--");
  mvprintw(11, 54, "|....|");
  mvprintw(12, 54, "|.$..|");
  mvprintw(13, 54, "------");

  mvprintw(13, 13, "----------");
  mvprintw(14, 13, "|........|  ###");
  mvprintw(15, 13, "|.......");

//  init_pair(7,COLOR_BLUE, COLOR_BLACK);
//  attron(COLOR_PAIR(7));
  mvprintw(15, 21, "}");
//  attroff(COLOR_PAIR(7));

  mvprintw(15, 22, "|");

  mvprintw(16, 13, "|........|");
  mvprintw(17, 13, "|........|");
  mvprintw(18, 13, "|........|");
  mvprintw(19, 13, "-----+----");

  mvprintw(15, 28, "---------");
  mvprintw(16, 28, "|....|..|");
  mvprintw(17, 28, "|....|.^|");
  mvprintw(18, 28, "+o...|..|");
  mvprintw(19, 28, "|.......|");
  mvprintw(20, 28, "|.......|");
  mvprintw(21, 28, "---------");

  mvprintw(7, 50, "   ####");
  mvprintw(8, 50, "  ######");
  mvprintw(9, 48, "##########");
  mvprintw(10, 50, "##");
  mvprintw(11, 50, "#");
  mvprintw(12, 50, "#");
  mvprintw(13, 26, "#########################");
  mvprintw(15, 24, "####");
  mvprintw(16, 24, "###");
  mvprintw(17, 24, "###");
  mvprintw(18, 24, "####");
  mvprintw(19, 24, "###");
  mvprintw(20, 18, "########");
}

int lvlTwo()
{
  clear();

  mvprintw(0, 0, "                                                                       ");
  mvprintw(1, 0, "                                                                       ");
  
  mvprintw(4, 23,  "---------");
  mvprintw(5, 23,  "|.......|      -----------");
  mvprintw(6, 23,  "|.......|      |..........|");
  mvprintw(7, 23,  "|.......|------|..........|");
  mvprintw(8, 23,  "|.........................|");
  mvprintw(9, 23,  "|.......|------|..........|");
  mvprintw(10, 23, "|.......|      -----+-----");
  mvprintw(11, 23, "---------");
}

char ** saveLevelPositions()
{
    int x, y;
    char ** positions;
    positions = malloc(sizeof(char *) * 25);

    for (y = 0; y < 25; y++)
    {
        positions[y] = malloc(sizeof(char) * 100);

        for (x = 0; x < 100; x++)
        {
            positions[y][x] = mvinch(y, x);
        }
    }

    return positions;
}
